# MAGNUS 2027 — Website

## Files
- `index.html` — homepage with the interactive campus fest map
- `events.html` — event timetable and participation information
- `food-fun.html` — food, clubs, activities and clickable campus map
- `registration.html` — registration form layout
- `contact.html` — contact and venue information
- `style.css` — shared styling and responsive map design
- `assets/campus-map.jpg` — original Magnus 2027 campus map image

## Preview locally
Open `index.html` in a browser. All five pages use relative links and share `style.css`.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload the six website files to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for the Pages URL to appear in the Pages settings.

## Important before publishing
- The registration form currently has no server or form-service connection. It displays the form but does not store submissions. Connect a form backend/service before collecting real registrations.
- Contact details, venue, fees, event dates and organiser information in the supplied pages include sample or unconfirmed details. Verify them and replace placeholders before publishing.
- The campus map is built with HTML and CSS, so it does not need a separate image asset.
